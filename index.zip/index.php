<html>
<head>
	<title>Compagnie lespatatesjaunes</title>
</head>
<body>
	<?php
		echo "Vous êtes sur le site des patates jaunes";
	?>
</body>
</html>
